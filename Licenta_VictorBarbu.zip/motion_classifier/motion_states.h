#ifndef MOTION_STATES_H
#define MOTION_STATES_H

// Motion state labels for drone movements
const char* MOTION_STATES[] = {
    "STATIONARY_FLAT",
    "STATIONARY_VERTICAL",
    "MOVING_UP",
    "MOVING_DOWN",
    "HOVERING",
    "MOVING_FORWARD",
    "MOVING_BACKWARD",
    "MOVING_LEFT",
    "MOVING_RIGHT",
    "ROTATING_CW",
    "ROTATING_CCW"
};

// Classification parameters
const float CONFIDENCE_THRESHOLD = 0.60f;

#endif // MOTION_STATES_H 