#ifndef SCALER_PARAMS_H
#define SCALER_PARAMS_H

// Scaler parameters for standardization
const float SCALER_MEAN[] = {-0.033467f, 0.013653f, 0.868125f};

const float SCALER_SCALE[] = {0.405953f, 0.180232f, 0.348536f};

#endif // SCALER_PARAMS_H
