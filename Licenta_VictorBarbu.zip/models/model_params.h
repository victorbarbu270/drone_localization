#ifndef MODEL_PARAMS_H
#define MODEL_PARAMS_H

#define SEQUENCE_LENGTH 50
#define N_FEATURES 3
#define N_CLASSES 11
#define DENSE1_UNITS 64
#define DENSE2_UNITS 32
#define FLATTENED_SIZE 150

#endif // MODEL_PARAMS_H
